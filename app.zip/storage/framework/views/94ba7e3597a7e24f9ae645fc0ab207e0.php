

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto mt-12 p-8 bg-white rounded-lg shadow-md">
    <h2 class="text-2xl font-bold mb-6 text-teal-800">Contact Us</h2>
    <?php if(session('success')): ?>
        <div class="mb-4 p-3 rounded bg-teal-100 text-teal-800 text-sm"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="mb-4 p-3 rounded bg-red-100 text-red-800 text-sm">
            <ul class="list-disc pl-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('contact.submit')); ?>" class="space-y-5">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name" class="block text-gray-700 font-medium mb-1">Name</label>
            <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" required
                class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-400">
        </div>
        <div>
            <label for="email" class="block text-gray-700 font-medium mb-1">Email</label>
            <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required
                class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-400">
        </div>
        <div>
            <label for="subject" class="block text-gray-700 font-medium mb-1">Subject</label>
            <input type="text" id="subject" name="subject" value="<?php echo e(old('subject')); ?>" required
                class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-400">
        </div>
        <div>
            <label for="message" class="block text-gray-700 font-medium mb-1">Message</label>
            <textarea id="message" name="message" rows="5" required
                class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-400"><?php echo e(old('message')); ?></textarea>
        </div>
        <button type="submit"
            class="w-full py-2 px-4 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded transition-colors">Send Message</button>
    </form>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\pelevo\backend\resources\views/contact.blade.php ENDPATH**/ ?>
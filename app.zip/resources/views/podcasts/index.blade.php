@extends('layouts.dashboard')

@section('title', 'Podcasts')

@section('content')
<h1 class="text-2xl font-bold text-gray-800 mb-6">Podcasts</h1>

<div class="bg-white rounded-lg shadow-lg p-6">
    <p class="text-gray-600">This is the Podcasts management page.</p>
</div>
@endsection 